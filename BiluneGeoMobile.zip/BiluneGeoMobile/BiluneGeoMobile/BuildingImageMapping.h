//
//  BuildingImageMapping.h
//  BiluneGeoMobile
//
//  Created by Marius Gächter on 22.07.13.
//  Copyright (c) 2013 leafit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BuildingImageMapping : NSObject
+(NSDictionary *)mappingDict;
@end

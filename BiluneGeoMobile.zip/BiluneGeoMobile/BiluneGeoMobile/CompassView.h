//
//  CompassView.h
//  BiluneGeoMobile
//
//  Created by Marius Gächter on 09.08.13.
//  Copyright (c) 2013 leafit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompassView : UILabel
-(void)rotate:(float)rotationDegrees;
@end
